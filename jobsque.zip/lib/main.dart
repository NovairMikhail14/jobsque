import 'package:flutter/material.dart';
import 'package:jobsque/app/app.dart';


void main() {
  runApp(MyApp());
}


