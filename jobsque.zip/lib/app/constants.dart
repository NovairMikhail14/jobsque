class Constants{
  static const String baseURL = "https://novairmikhail14.mocklab.io/";
  static const String empty = "";
  static const int zero = 0;
}