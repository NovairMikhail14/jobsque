
import 'package:flutter/material.dart';
import 'package:jobsque/presentation/applied_job/applied_job_view.dart';
import 'package:jobsque/presentation/applied_job/biodata/biodata_view.dart';
import 'package:jobsque/presentation/applied_job/type_work/type_work_view.dart';
import 'package:jobsque/presentation/applied_job/upload_portfolio/upload_portfolio_view.dart';
import 'package:jobsque/presentation/end_page/noAppRejected_View..dart';
import 'package:jobsque/presentation/home_screen/home_screen_view.dart';
import 'package:jobsque/resources/theme_manager.dart';

class MyApp extends StatelessWidget {
  MyApp._internal();
  static final MyApp _instance = MyApp._internal();
  factory MyApp() => _instance;

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    TextEditingController tc = TextEditingController();
    return MaterialApp(
      title: 'Flutter Demo',
      theme: getApplicationTheme(),
      debugShowCheckedModeBanner: false,
      // onGenerateRoute: RouteGenerator.getRoute,
      // initialRoute: Routes.createAccountRoute,
      home: HomeScreenView(),
    );
  }
}