import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:jobsque/presentation/widgets/job_steps.dart';
import 'package:jobsque/resources/color_manger.dart';
import 'package:jobsque/resources/strings_manager.dart';
import 'package:jobsque/resources/value_manager.dart';

class JobTile extends StatefulWidget {
  String title;
  String subtitle;
  String imagePath;

  JobTile(
      {required this.title, required this.subtitle, required this.imagePath});

  @override
  State<JobTile> createState() => _JobTileState();
}

class _JobTileState extends State<JobTile> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom:  AppSize.s12),
      padding: const EdgeInsets.all(AppSize.s12),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            width: 2,
            color: ColorManager.neutral200
          )
        )
      ),
      child: Column(
        children: [
          ListTile(
            title: Text(widget.title),
            subtitle: Text(widget.subtitle),
            leading: SvgPicture.asset(widget.imagePath),
            trailing: Icon(Icons.archive_outlined),
          ),
          Row(
            children: [
              Container(
                padding: EdgeInsets.fromLTRB(AppPadding.p12, AppPadding.p10, AppPadding.p12, AppPadding.p10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(AppSize.s20),
                      color: ColorManager.primary100),
                  child: Text(AppStrings.appliedJobFullTime,style: Theme.of(context).textTheme.bodySmall!.copyWith(color: ColorManager.primary500),)),
              SizedBox(width: AppSize.s10,),
              Container(
                  padding: EdgeInsets.fromLTRB(AppPadding.p12, AppPadding.p10, AppPadding.p12, AppPadding.p10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(AppSize.s20),
                      color: ColorManager.primary100),
                  child: Text(AppStrings.appliedJobRemote,style: Theme.of(context).textTheme.bodySmall!.copyWith(color: ColorManager.primary500),)),
              Spacer(
                flex: 1,
              ),
              Text("Posted 2 days ago")
            ],
          ),
          SizedBox(height: AppSize.s10,),
          JobSteps()
        ],
      ),
    );
  }
}
